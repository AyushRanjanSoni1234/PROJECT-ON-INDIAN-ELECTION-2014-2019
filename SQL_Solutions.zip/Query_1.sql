use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

select * from dim_states_codes;

-- data cleaning
/* In 2014, Andhra Pradesh underwent bifurcation. For simplicity,
all constituencies from that year should be attributed to Telangana state. 
This includes constituencies such as Adilabad, Hyderabad, Warangal, etc., 
which should be considered part of Telangana rather than Andhra Pradesh for the year 2014. */
SET SQL_SAFE_UPDATES = 0;

update constituency_wise_results_2014
set state = "Telangana"
where pc_name in ("Adilabad", "Bhongir", "CHELVELLA", "Hyderabad", "Karimnagar", "Khammam", 
"Mahabubabad", "Mahbubnagar", "Malkajgiri", "Medak", "Nagarkurnool", "Nalgonda",
"Nizamabad", "Peddapalle", "Secundrabad", "Warangal", "Zahirabad"); 

SET SQL_SAFE_UPDATES = 1;

select * from constituency_wise_results_2014;

-- 1. List top 5/ bottom 5 constituencies of 2014 and 2019 in terms of voter turnout ratio?
-- SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

-- Top 5 constituencies of 2019 in terms of voter turnout ratio.
select pc_name , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2019
group by pc_name
order by 2 desc
limit 5;

-- Bottom 5 constituencies of 2019 in terms of voter turnout ratio.
select pc_name , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2019
group by pc_name
order by 2 asc
limit 5;

-- Top 5 constituencies of 2014 in terms of voter turnout ratio.
select pc_name , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2014
group by pc_name
order by 2 desc
limit 5;

-- Bottom 5 constituencies of 2014 in terms of voter turnout ratio.
select pc_name , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2014
group by pc_name
order by 2 asc
limit 5;

-- 2. List top 5 / bottom 5 states of 2014 and 2019 in terms of voter turnout ratio?

-- Top 5 States of 2019 in terms of voter turnout ratio.
select state , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2019
group by 1
order by 2 desc
limit 5;

-- Bottom 5 States of 2019 in terms of voter turnout ratio.
select state , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2019
group by 1
order by 2 asc
limit 5;

-- Top 5 States of 2014 in terms of voter turnout ratio.
select state , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2014
group by 1
order by 2 desc
limit 5;

-- Bottom 5 States of 2014 in terms of voter turnout ratio.
select state , avg((total_votes/total_electors)*100) as voter_turnout_ratio
from constituency_wise_results_2014
group by 1
order by 2 asc
limit 5;

