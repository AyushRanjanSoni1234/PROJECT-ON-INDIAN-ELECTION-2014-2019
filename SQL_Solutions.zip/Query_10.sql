use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

-- Which constituency has voted the most for NOTA?

select pc_name, party, sum(total_votes) from constituency_wise_results_2014
where party like '%NOTA%'
group by 1, 2;

select pc_name, party, sum(total_votes) from constituency_wise_results_2019
where party = 'NOTA'
group by 1, 2;

select count(*) from constituency_wise_results_2014;
select count(*) from constituency_wise_results_2019;