use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

/* List top 5 constituencies for two major national parties where they have lost vote share in 2019 
as compared to 2014. */

(select a.pc_name, a.party, a.total_votes as 2019_votes, 
b.total_votes as 2014_votes, ((a.total_votes-b.total_votes)/b.total_votes)*100 as gained_votes
from constituency_wise_results_2019 as a
inner join
constituency_wise_results_2014 as b
on a.pc_name = b.pc_name
where a.party = 'BJP'
order by 5 asc
limit 5)
union
(select a.pc_name, a.party, a.total_votes as 2019_votes, 
b.total_votes as 2014_votes, ((a.total_votes-b.total_votes)/b.total_votes)*100 as gained_votes
from constituency_wise_results_2019 as a
inner join
constituency_wise_results_2014 as b
on a.pc_name = b.pc_name
where a.party = 'INC'
order by 5 asc
limit 5);