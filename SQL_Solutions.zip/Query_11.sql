use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

-- Which constituencies have elected candidates whose party has less than 10% vote share at state level in 2019?

with temp1 as(
select state, pc_name, party, total_votes,
sum(total_votes) over(partition by state) as State_votes
from constituency_wise_results_2019),
temp2 as(
select state, pc_name, party, ((total_votes/State_votes)*100) as vote_share_pct_at_state
from temp1
where total_votes in (select max(total_votes) from constituency_wise_results_2019
group by pc_name))
select pc_name, party from temp2
where vote_share_pct_at_state < 10;


