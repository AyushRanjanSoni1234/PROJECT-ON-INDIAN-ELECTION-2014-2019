use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

-- Top 5 candidates based on margin difference with runners in 2014 and 2019.

with temp_2014 as(
select pc_name, candidate, total_votes from constituency_wise_results_2014 
where total_votes in (select max(total_votes) as winning_votes
from constituency_wise_results_2014
group by pc_name)),
temp_2019 as(
select pc_name, candidate, total_votes from constituency_wise_results_2019
where total_votes in (select max(total_votes) as winning_votes
from constituency_wise_results_2019
group by pc_name))
-- temp_table as(
select temp_2019.pc_name as constituencies,
temp_2019.candidate as 2019_candidate, 
temp_2014.candidate as 2014_candidate,
(temp_2019.total_votes)-(temp_2014.total_votes) as margin 
from temp_2019
inner join temp_2014
on temp_2019.pc_name = temp_2014.pc_name
order by margin desc
limit 5;

