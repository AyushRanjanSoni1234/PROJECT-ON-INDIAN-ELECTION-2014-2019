use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

/* Which constituencies have voted for different parties in two elections 
(list top 10 based on difference (2019-2014) in winner vote percentage in two elections) */

with temp_2014 as(
select pc_name, max(winning_percentage_2014) as max_pct from (select pc_name, party, party_symbol, round((total_votes/total_electors)*100,2) as winning_percentage_2014
from constituency_wise_results_2014) as a
group by 1 ),
temp_2019 as(
select pc_name, max(winning_percentage_2019) as max_pct from (select pc_name, party, party_symbol, round((total_votes/total_electors)*100,2) as winning_percentage_2019
from constituency_wise_results_2019) as b
group by 1 ),
temp_table as(
select temp_2019.pc_name as constituencies,(temp_2019.max_pct)-(temp_2014.max_pct) as winning_diff 
from temp_2019
inner join temp_2014
on temp_2019.pc_name = temp_2014.pc_name)
select constituencies, winning_diff from temp_table
order by 2 desc
limit 10;
