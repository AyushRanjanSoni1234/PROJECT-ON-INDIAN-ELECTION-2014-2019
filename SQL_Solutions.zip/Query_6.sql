use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

-- % Split of votes of parties between 2014 vs 2019 at national level

with temp_2014 as(
select party, avg(vote_pct) as total_votes
from ( select *, ((total_votes/total_electors)*100) as vote_pct from constituency_wise_results_2014) as a
where party in ('BJP', 'INC', 'CPI', 'CPI(M)', 'BSP', 'NCP', 'AITC', 'NPP', 'APP')
group by party
order by 2 desc),
temp_2019 as(
select party, avg(vote_pct) as total_votes
from ( select *, ((total_votes/total_electors)*100) as vote_pct from constituency_wise_results_2019) as a
where party in ('BJP', 'INC', 'CPI', 'CPI(M)', 'BSP', 'NCP', 'AITC', 'NPP', 'APP')
group by party
order by 2 desc)
select temp_2019.party as Party_name, temp_2019.total_votes as pct_votes_2019,
temp_2014.total_votes as pct_votes_2014, 
(temp_2019.total_votes-temp_2014.total_votes) as changes_percentage
from temp_2019
inner join temp_2014
on temp_2019.party = temp_2014.party;

