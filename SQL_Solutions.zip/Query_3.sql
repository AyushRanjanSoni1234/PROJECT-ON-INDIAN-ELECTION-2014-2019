use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

select * from dim_states_codes;

/* 3. Which constituencies have elected the same party for two consecutive elections, 
rank them by % of votes to that winning party in 2019 */
with temp1 as(
select pc_name, party, party_symbol, total_votes
from constituency_wise_results_2014
where total_votes in 
(select max_votes from 
(select pc_name, max(total_votes) as max_votes from constituency_wise_results_2014 group by 1) as a)
),
temp2 as(
select pc_name, party, party_symbol, total_votes
from constituency_wise_results_2019
where total_votes in 
(select max_votes from 
(select pc_name, max(total_votes) as max_votes from constituency_wise_results_2019 group by 1) as a))
select temp1.pc_name, temp1.party, dense_rank() over(order by temp2.total_votes) as _Rank
from temp1 inner join temp2
on temp1.pc_name = temp2.pc_name
where temp1.party = temp2.party;