use Election_data_survey;

select * from constituency_wise_results_2014;

select * from constituency_wise_results_2019;

-- List top 5 / bottom 5 states of 2014 and 2019 in terms of voter turnout ratio?

SELECT distinct
    t2019.state AS top_states_2019,
    t2019.voter_turnout_ratio AS voter_turnout_ratio_2019,
    b2019.state AS bottom_states_2019,
    b2019.voter_turnout_ratio AS voter_turnout_ratio_2019,
    t2014.state AS top_states_2014,
    t2014.voter_turnout_ratio AS voter_turnout_ratio_2014,
    b2014.state AS bottom_states_2014,
    b2014.voter_turnout_ratio AS voter_turnout_ratio_2014
FROM 
    (SELECT state, AVG((total_votes/total_electors)*100) AS voter_turnout_ratio 
     FROM constituency_wise_results_2019 
     GROUP BY state 
     ORDER BY voter_turnout_ratio DESC 
     LIMIT 5) AS t2019
JOIN 
    (SELECT state, AVG((total_votes/total_electors)*100) AS voter_turnout_ratio 
     FROM constituency_wise_results_2019 
     GROUP BY state 
     ORDER BY voter_turnout_ratio ASC 
     LIMIT 5) AS b2019 ON 1=1
JOIN 
    (SELECT state, AVG((total_votes/total_electors)*100) AS voter_turnout_ratio 
     FROM constituency_wise_results_2014 
     GROUP BY state 
     ORDER BY voter_turnout_ratio DESC 
     LIMIT 5) AS t2014 ON 1=1
JOIN 
    (SELECT state, AVG((total_votes/total_electors)*100) AS voter_turnout_ratio 
     FROM constituency_wise_results_2014 
     GROUP BY state
     ORDER BY voter_turnout_ratio ASC 
     LIMIT 5) AS b2014 ON 1=1;
